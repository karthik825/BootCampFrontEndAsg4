using Microsoft.AspNetCore.Mvc;
using EMPH3697_KARTHIK.Model;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EMPH3697_KARTHIK.Controllers
{
   
    public class ProductsController : Controller
    {

        [HttpGet]
        [Route("/GetAllProducts")]
        public IActionResult GetAllProducts()
        {
            try
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "data.json");
                string data = System.IO.File.ReadAllText(filePath);
                JObject json = JObject.Parse(data);

                if (json["Products"] != null)
                {
                    List<Products> products = JsonConvert.DeserializeObject<List<Products>>(json["Products"].ToString());
                    return Ok(products);
                }
                else
                {
                    return BadRequest("Invalid JSON data format.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }
        }

        [HttpGet]
        [Route("/GetProductById/{id}")]
        public IActionResult GetProductById(int id)
        {
            try
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "data.json");
                string data = System.IO.File.ReadAllText(filePath);
                JObject json = JObject.Parse(data);

                if (json["Products"] != null)
                {
                    List<Products> products = JsonConvert.DeserializeObject<List<Products>>(json["Products"].ToString());
                    Products product = products.FirstOrDefault(p => p.Id == id);

                    if (product != null)
                    {
                        return Ok(product);
                    }
                    else
                    {
                        return NotFound($"Product with ID {id} not found.");
                    }
                }
                else
                {
                    return BadRequest("Invalid JSON data format.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }
        }

        [HttpPost]
        [Route("/CreateProduct")]
        public IActionResult CreateProduct([FromBody] Products newProduct)
        {
            try
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "data.json");
                string data = System.IO.File.ReadAllText(filePath);
                JObject json = JObject.Parse(data);

                List<Products> products = json["Products"].ToObject<List<Products>>();
                newProduct.Id = products.Max(p => p.Id) + 1;

                products.Add(newProduct);
                json["Products"] = JToken.FromObject(products);

                System.IO.File.WriteAllText(filePath, json.ToString());

                return CreatedAtAction(nameof(GetProductById), new { id = newProduct.Id }, newProduct);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }
        }

        [HttpPut]
        [Route("/UpdateProduct/{id}")]
        public IActionResult UpdateProduct(int id, [FromBody] Products updatedProduct)
        {
            try
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "data.json");
                string data = System.IO.File.ReadAllText(filePath);
                JObject json = JObject.Parse(data);

                List<Products> products = json["Products"].ToObject<List<Products>>();
                Products existingProduct = products.FirstOrDefault(p => p.Id == id);

                if (existingProduct != null)
                {
                    existingProduct.Name = updatedProduct.Name;
                    existingProduct.Description = updatedProduct.Description;
                    existingProduct.Price = updatedProduct.Price;
                    existingProduct.QuantityAvailable = updatedProduct.QuantityAvailable;

                    json["Products"] = JToken.FromObject(products);
                    System.IO.File.WriteAllText(filePath, json.ToString());

                    return Ok(existingProduct);
                }
                else
                {
                    return NotFound($"Product with ID {updatedProduct.Id} not found.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }
        }

        [HttpDelete]
        [Route("/DeleteProduct/{id}")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "data.json");
                string data = System.IO.File.ReadAllText(filePath);
                JObject json = JObject.Parse(data);

                List<Products> products = json["Products"].ToObject<List<Products>>();
                Products existingProduct = products.FirstOrDefault(p => p.Id == id);

                if (existingProduct != null)
                {
                    products.Remove(existingProduct);
                    json["Products"] = JToken.FromObject(products);
                    System.IO.File.WriteAllText(filePath, json.ToString());

                    return NoContent();
                }
                else
                {
                    return NotFound($"Product with ID {id} not found.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }
        }
    }
}
